<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .header-div {
            background-color: rgb(108, 92, 57);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 70px;
            color: rgb(250, 243, 228);
        }

        .header-text {
            font-size: 36px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .config-button, .logout-button {
            font-size: 18px;
            background-color: rgb(250, 243, 228);
            color: rgb(108, 92, 57);
            padding: 8px 15px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: background-color 0.3s, color 0.3s;
        }

        .config-button:hover, .logout-button:hover {
            background-color: rgb(108, 92, 57);
            color: rgb(250, 243, 228);
        }

        .offcanvas-top-custom {
            height: 80vh;
        }

        .offcanvas-header {
            background-color: rgb(108, 92, 57);
            color: rgb(250, 243, 228);
        }

        .offcanvas-body {
            background-color: rgb(250, 243, 228);
            padding: 20px;
        }

        .table {
            background-color: rgb(250, 243, 228);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .btn-success,
        .btn-warning,
        .btn-info,
        .btn-danger {
            font-size: 14px;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .btn-close {
            color: rgb(250, 243, 228);
        }
    </style>
</head>

<body>
    <div class="header-div">
        <p class="header-text">Bienvenido a la página web</p>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
            <button class="config-button" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasAdmin"
                aria-controls="offcanvasAdmin">
                <i class="bi bi-gear"></i> Configuración de Admin
            </button>
        <?php endif; ?>

        <!-- Botón de Cerrar sesión -->
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-button">Cerrar sesión</button>
        </form>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
        <div class="offcanvas offcanvas-top offcanvas-top-custom" tabindex="-1" id="offcanvasAdmin"
            aria-labelledby="offcanvasAdminLabel">
            <div class="offcanvas-header">
                <h5 id="offcanvasAdminLabel">Administración de Usuarios</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
            </div>
            <div class="offcanvas-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->actived ? 'Activo' : 'Inactivo'); ?></td>
                                <td>
                                    <!-- Activar/Desactivar -->
                                    <?php if($user->email_confirmed && !$user->actived): ?>
                                        <form method="POST" action="<?php echo e(route('admin.users.activate', $user->id)); ?>" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-success btn-sm" type="submit">Activar</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if($user->actived): ?>
                                        <form method="POST" action="<?php echo e(route('admin.users.deactivate', $user->id)); ?>" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-warning btn-sm" type="submit">Desactivar</button>
                                        </form>
                                    <?php endif; ?>

                                    <!-- Editar -->
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info btn-sm">Editar</a>

                                    <!-- Eliminar -->
                                    <form method="POST" action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\Users\juanc\OneDrive\Desktop\2DAM\Interfaces\Proyecto\Grupo_3_Interfaces_David_Alvaro\Eventify\resources\views/home.blade.php ENDPATH**/ ?>