<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Bienvenido a la página web</h1>

        <!-- Verificar si el usuario tiene permiso de administrador -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
            <!-- Botón para abrir el offcanvas de configuración de administrador -->
            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasAdmin" aria-controls="offcanvasAdmin">
                <i class="bi bi-gear"></i> Configuración de Admin
            </button>

            <!-- Offcanvas de Administración de Usuarios -->
            <div class="offcanvas offcanvas-top offcanvas-fullscreen" tabindex="-1" id="offcanvasAdmin" aria-labelledby="offcanvasAdminLabel">
                <div class="offcanvas-header">
                    <h5 id="offcanvasAdminLabel">Administración de Usuarios</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body" style="overflow-y: auto;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Iteración de usuarios y opciones de activación/desactivación -->
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->actived ? 'Activo' : 'Inactivo'); ?></td>
                                    <td>
                                        <?php if($user->email_confirmed && !$user->actived): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.activate', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-success btn-sm" type="submit">Activar</button>
                                            </form>
                                        <?php endif; ?>
                                        <?php if($user->actived): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.deactivate', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-warning btn-sm" type="submit">Desactivar</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\juanc\OneDrive\Desktop\2DAM\Interfaces\Proyecto\Grupo_3_Interfaces_David_Alvaro\Eventify\resources\views/home.blade.php ENDPATH**/ ?>