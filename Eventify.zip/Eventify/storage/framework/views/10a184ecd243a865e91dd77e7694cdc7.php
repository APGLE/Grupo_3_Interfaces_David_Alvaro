<?php $__env->startSection('content'); ?>
    <div id="app">
        <create-event-component></create-event-component>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juanc\OneDrive\Desktop\2DAM\Interfaces\Proyecto\Grupo_3_Interfaces_David_Alvaro\Eventify\resources\views/create_event.blade.php ENDPATH**/ ?>