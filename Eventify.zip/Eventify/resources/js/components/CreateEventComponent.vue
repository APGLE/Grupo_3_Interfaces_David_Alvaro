<template>
  <div class="divCrud">
    <h2 style="margin-right: 40px; color: rgb(250, 243, 228)">Crear Nuevo Evento</h2>
    <form @submit.prevent="submitEvent">
      <div>
        <label for="title">Título:</label>
        <input style="width:100%;border-radius: 5px;" type="text" v-model="event.title" required />
      </div>
      <div>
        <label for="category">Categoría:</label>
        <select style="width:100%;border-radius: 5px;" v-model="event.category_id" required>
          <option value="1">Música</option>
          <option value="2">Deporte</option>
          <option value="3">Tecnología</option>
        </select>
      </div>
      <div>
        <label for="date">Fecha de Inicio:</label>
        <input style="width:100%;border-radius: 5px;" type="datetime-local" v-model="event.start_time" required />
      </div>
      <div>
        <label for="date">Fecha de Fin:</label>
        <input style="width:100%;border-radius: 5px;" type="datetime-local" v-model="event.end_time" required />
      </div>
      <div>
        <label for="description">Descripción:</label>
        <textarea style="width:100%;border-radius: 5px;" v-model="event.description" required></textarea>
      </div>
      <div>
        <label for="location">Ubicación:</label>
        <input style="width:100%;border-radius: 5px;" type="text" v-model="event.location" required />
      </div>
      <div>
        <label for="organized_id">ID del Organizador:</label>
        <input style="width:100%;border-radius: 5px;" type="number" v-model="event.organized_id" required />
      </div>
      <div>
        <label for="image">Imagen:</label>
        <input style="width:100%;border-radius: 5px;" type="file" @change="handleImageUpload" required />
      </div>
      <button type="submit">Crear Evento</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      event: {
        title: '',
        category_id: '',
        start_time: '',
        end_time: '',
        description: '',
        location: '',
        latitude: '',
        longitude: '',
        price: '',
        max_attendees: '',
        organized_id: ''
      },
      image: null
    };
  },
  methods: {
    async submitEvent() {
      // Validación previa para asegurar que end_time es después de start_time
      if (new Date(this.event.end_time) <= new Date(this.event.start_time)) {
        alert("La fecha de fin debe ser posterior a la fecha de inicio.");
        return;
      }

      try {
        const formData = new FormData();
        formData.append('title', this.event.title);
        formData.append('category_id', this.event.category_id);
        formData.append('description', this.event.description);
        formData.append('start_time', this.event.start_time);
        formData.append('end_time', this.event.end_time);
        formData.append('location', this.event.location);
        formData.append('latitude', this.event.latitude);
        formData.append('longitude', this.event.longitude);
        formData.append('price', this.event.price);
        formData.append('max_attendees', this.event.max_attendees);
        formData.append('organized_id', this.event.organized_id);
        formData.append('image', this.image);

        // CSRF token
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

        const response = await fetch('/events/create', {
          method: 'POST',
          body: formData
        });

        if (response.ok) {
          alert('Evento creado con éxito');
          this.resetForm();
        } else {
          alert('Error al crear el evento');
        }
      } catch (error) {
        console.error('Error al enviar el evento:', error);
        alert('Error al crear el evento');
      }
    },
    handleImageUpload(event) {
      this.image = event.target.files[0];
    },
    resetForm() {
      this.event = {
        title: '',
        category_id: '',
        start_time: '',
        end_time: '',
        description: '',
        location: '',
        latitude: '',
        longitude: '',
        price: '',
        max_attendees: '',
        organized_id: ''
      };
      this.image = null;
    }
  }
};
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
}
form > div {
  margin-bottom: 10px;
}
button {
  align-self: flex-start;
}
.divCrud {
  margin: 20%;
  display: flex;
  place-content: center;
  align-items: center;
  background: rgb(108, 92, 57);
  border-radius: 10px;
  padding: 20px;
  color: rgb(108, 92, 57);
}
label {
  color: rgb(250, 243, 228);
}
</style>
