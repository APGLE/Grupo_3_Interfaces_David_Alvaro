<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Correo</title>
</head>
<body>
    <h1>Verifica tu Correo Electrónico</h1>
    <p>Por favor, haz clic en el siguiente enlace para verificar tu dirección de correo electrónico:</p>
    <a href="{{ $verificationUrl }}" class="button">Verificar Correo Electrónico</a>
</body>
</html>
